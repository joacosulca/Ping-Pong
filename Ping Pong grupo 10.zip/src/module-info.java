/**
 * 
 */
/**
 * 
 */
module pingPong {
	requires java.desktop;
}